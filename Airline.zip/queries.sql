# Number of active planes
SELECT count(*) 'active planes number'
FROM planes
WHERE status = 'active';

# All employees who are flight attendants
SELECT * 
FROM employees e, roles r
WHERE e.role_id = r.role_id AND r.role_name = 'flight attendant';

# The highest payed role
SELECT r.role_name
FROM employees e, roles r
WHERE e.role_id = r.role_id AND e.salary = (SELECT MAX(salary) FROM employees);

# Ratio of sum payed via credit cards vs cash
SELECT
((SELECT SUM(price)
FROM orders
GROUP BY payment_method
HAVING payment_method = 'credit card')
/
(SELECT SUM(price)
FROM orders
GROUP BY payment_method
HAVING payment_method = 'cash')) 'total credit card/cash';

# All passengers who took flight on a plane with specific name
SELECT ps.* 
FROM plane_types pt
LEFT JOIN planes p ON pt.plane_type = p.plane_type
LEFT JOIN flights f ON p.plane_id = f.plane_id
LEFT JOIN tickets t ON f.flight_id = t.flight_id
LEFT JOIN passengers ps ON t.passenger_id = ps.passenger_id
WHERE ps.passenger_id IS NOT NULL AND p.name = 'Saro Deravanesian';

# All the destination cities grouped by their country name
SELECT country, GROUP_CONCAT(DISTINCT city SEPARATOR ', ') cities, GROUP_CONCAT(DISTINCT airport_code SEPARATOR ', ') airport_code
FROM destinations
GROUP BY country;

# Calories in a most nutritious food on every flight
SELECT f.flight_number, MAX(fi.calories) 'calories'
FROM flights f
LEFT JOIN food_menu fm ON f.menu_id = fm.menu_id
LEFT JOIN food_items fi ON fm.foods_id = fi.menu_foods_id
GROUP BY f.flight_number;
