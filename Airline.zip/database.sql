-- MySQL dump 10.13  Distrib 8.0.30, for macos12 (arm64)
--
-- Host: localhost    Database: Airline
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `destinations`
--

DROP TABLE IF EXISTS `destinations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `destinations` (
  `airport_code` varchar(45) NOT NULL,
  `city` varchar(45) NOT NULL,
  `country` varchar(45) NOT NULL,
  `distance_from_base` int NOT NULL,
  PRIMARY KEY (`airport_code`),
  UNIQUE KEY `airport_code_UNIQUE` (`airport_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `destinations`
--

LOCK TABLES `destinations` WRITE;
/*!40000 ALTER TABLE `destinations` DISABLE KEYS */;
INSERT INTO `destinations` VALUES ('BML','Berlin','Germany',2140),('DXB','Dubai','UAE',1130),('EVN','Yerevan','Armenia',0),('JFK','New York','USA',15000),('LAX','Los Angeles','USA',17800),('MOW','Moscow','Russia',2000);
/*!40000 ALTER TABLE `destinations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `employee_id` int NOT NULL AUTO_INCREMENT,
  `role_id` int NOT NULL,
  `corporate_phone_number` varchar(45) DEFAULT NULL,
  `first_name` varchar(45) NOT NULL,
  `middle_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) NOT NULL,
  `DOB` date NOT NULL,
  `gender` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `street` varchar(100) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `ZIP` int DEFAULT NULL,
  `salary` int NOT NULL,
  PRIMARY KEY (`employee_id`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `employee_id_UNIQUE` (`employee_id`),
  KEY `role_id_idx` (`role_id`),
  CONSTRAINT `role_id` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (11,3,'3437846537','Mkrtich',NULL,'Poghosyan','1997-03-12','male','mko-pogh@mail.com','Arshakunyants 23','Yerevan','Armenia',120,250000),(12,5,'8675434566','Artur',NULL,'Mikaelyan','1985-06-18','male','artur3332@gmail.com','Mashtots Ave. 30','Yerevan','Armenia',2,430000),(13,1,'3456543243','John','Mike','Anderson','1990-01-30','male','john.a43@yahoo.com','45 North Ave','New York','USA',19321,900000),(14,5,'6456453655','Anna',NULL,'Sargsyan','2000-03-11','female','anna032@gmail.com','Bagratunyants 86','Gyumri','Armenia',213,425000);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flights`
--

DROP TABLE IF EXISTS `flights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flights` (
  `flight_id` int NOT NULL AUTO_INCREMENT,
  `plane_id` int DEFAULT NULL,
  `menu_id` int DEFAULT NULL,
  `flight_number` varchar(45) NOT NULL,
  `origin_airport` varchar(45) NOT NULL,
  `destination_airport` varchar(45) NOT NULL,
  `travel_time` int NOT NULL,
  `departure_time` datetime DEFAULT NULL,
  `arrival_time` datetime DEFAULT NULL,
  `flight_status` varchar(45) NOT NULL,
  `crew_number` int NOT NULL,
  PRIMARY KEY (`flight_id`),
  UNIQUE KEY `flight_id_UNIQUE` (`flight_id`),
  KEY `plane_id_idx` (`plane_id`),
  KEY `plane_id_idx1` (`plane_id`),
  KEY `menu_id_idx` (`menu_id`),
  KEY `destination_airport_idx` (`destination_airport`),
  CONSTRAINT `destination_airport` FOREIGN KEY (`destination_airport`) REFERENCES `destinations` (`airport_code`),
  CONSTRAINT `menu_id` FOREIGN KEY (`menu_id`) REFERENCES `food_menu` (`menu_id`),
  CONSTRAINT `plane_id` FOREIGN KEY (`plane_id`) REFERENCES `planes` (`plane_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9879 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flights`
--

LOCK TABLES `flights` WRITE;
/*!40000 ALTER TABLE `flights` DISABLE KEYS */;
INSERT INTO `flights` VALUES (1240,163,3,'AM197','DXB','EVN',85,'2023-01-03 07:30:00','2023-01-03 09:30:00','Scheduled',6),(5432,54,2,'AM701','NYC','EVN',720,'2022-11-16 14:00:00','2022-11-04 02:15:00','Completed',12),(5646,213,1,'AM321','EVN','BML',240,'2022-10-04 09:30:00','2022-10-04 12:30:00','Completed',8),(8243,106,5,'AM028','EVN','LAX',815,'2022-12-25 02:30:00','2022-12-25 16:00:00','Scheduled',13),(9878,12,3,'AM228','MOW','EVN',260,'2022-12-06 12:30:00','2022-12-06 15:30:00','Completed',7);
/*!40000 ALTER TABLE `flights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `food_items`
--

DROP TABLE IF EXISTS `food_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `food_items` (
  `food_id` int NOT NULL AUTO_INCREMENT,
  `menu_foods_id` int DEFAULT NULL,
  `food_name` varchar(45) NOT NULL,
  `storage_temperature` int DEFAULT NULL,
  `calories` int DEFAULT NULL,
  `expiration_time` int DEFAULT NULL,
  PRIMARY KEY (`food_id`),
  UNIQUE KEY `food_id_UNIQUE` (`food_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food_items`
--

LOCK TABLES `food_items` WRITE;
/*!40000 ALTER TABLE `food_items` DISABLE KEYS */;
INSERT INTO `food_items` VALUES (1,21,'Salad',8,40,24),(2,54,'Soup',8,150,24),(3,43,'Burger',8,130,48),(4,32,'Dumplings',8,160,48),(5,12,'Xorovats',20,300,24),(6,10,'Sushi',8,200,24),(7,50,'Pizza',8,185,24),(8,12,'Dolma',8,210,48),(9,NULL,'Pasta',23,120,48);
/*!40000 ALTER TABLE `food_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `food_menu`
--

DROP TABLE IF EXISTS `food_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `food_menu` (
  `menu_id` int NOT NULL AUTO_INCREMENT,
  `foods_id` int NOT NULL,
  `creation_date` datetime NOT NULL,
  `type` varchar(45) DEFAULT NULL,
  `season` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`menu_id`,`foods_id`),
  UNIQUE KEY `menu_id_UNIQUE` (`menu_id`),
  UNIQUE KEY `foods_id_UNIQUE` (`foods_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food_menu`
--

LOCK TABLES `food_menu` WRITE;
/*!40000 ALTER TABLE `food_menu` DISABLE KEYS */;
INSERT INTO `food_menu` VALUES (1,21,'2022-12-04 06:44:17','Vegeterian','Summer'),(2,54,'2022-03-24 09:12:17','Spicy','All'),(3,43,'2022-06-01 09:12:17','Kids','All'),(4,32,'2022-02-10 09:12:17','Chinese','Winter'),(5,12,'2022-11-11 09:12:17','Armenian','All'),(6,10,'2022-09-23 09:12:17','Japanese','Summer'),(7,50,'2022-12-02 09:12:17',NULL,'All');
/*!40000 ALTER TABLE `food_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `order_id` int NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `price` int NOT NULL,
  `order_method` varchar(45) DEFAULT NULL,
  `payment_method` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `order_id_UNIQUE` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=89878 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (32434,'2022-11-04 06:10:17',85000,'online','credit card'),(37822,'2022-01-01 13:44:17',214000,'online','paypal'),(43543,'2022-06-24 00:44:17',150000,'office','cash'),(89877,'2022-04-04 17:44:17',340000,'office','credit card');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passengers`
--

DROP TABLE IF EXISTS `passengers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `passengers` (
  `passenger_id` int NOT NULL AUTO_INCREMENT,
  `phone_numbers_id` int NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `middle_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) NOT NULL,
  `DOB` date NOT NULL,
  `gender` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `street` varchar(100) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `ZIP` int DEFAULT NULL,
  PRIMARY KEY (`passenger_id`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `passenger_id_UNIQUE` (`passenger_id`),
  UNIQUE KEY `phone_numbers_id_UNIQUE` (`phone_numbers_id`),
  CONSTRAINT `phone_numbers_id` FOREIGN KEY (`phone_numbers_id`) REFERENCES `phone_numbers` (`phone_numbers_id`)
) ENGINE=InnoDB AUTO_INCREMENT=985 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passengers`
--

LOCK TABLES `passengers` WRITE;
/*!40000 ALTER TABLE `passengers` DISABLE KEYS */;
INSERT INTO `passengers` VALUES (192,964,'Nancy',NULL,'Pelosy','1928-03-13','female','nancy@gov.us','White House','Washington DC','USA',38131),(231,234,'Tigran',NULL,'Arzaqancyan','1972-04-02','male','tigran.arz723@gmail.com','North Ave 18','Yerevan','Armenia',1),(324,134,'Hakob',NULL,'Minasyan','1978-02-18','male','hakob37@yahoo.com','Melkumov 23','Yerevan','Armenia',11),(566,324,'Vasak',NULL,'Mamikonyan','1954-09-08','male','vasak.m82@yandex.ru','Baghramyan 80','Artashat','Armenia',213),(984,643,'Armen',NULL,'Mkrtumyan','2000-07-11','male','armen.dzya@gmail.com','Frunze 52','Yerevan','Armenia',12);
/*!40000 ALTER TABLE `passengers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phone_numbers`
--

DROP TABLE IF EXISTS `phone_numbers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phone_numbers` (
  `phone_numbers_id` int NOT NULL,
  `phone_number` varchar(45) NOT NULL,
  PRIMARY KEY (`phone_numbers_id`,`phone_number`),
  UNIQUE KEY `phone_number_UNIQUE` (`phone_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phone_numbers`
--

LOCK TABLES `phone_numbers` WRITE;
/*!40000 ALTER TABLE `phone_numbers` DISABLE KEYS */;
INSERT INTO `phone_numbers` VALUES (134,'3474357435'),(964,'3563663633'),(324,'5467549649'),(234,'6345635553'),(643,'7456746574');
/*!40000 ALTER TABLE `phone_numbers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plane_types`
--

DROP TABLE IF EXISTS `plane_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plane_types` (
  `plane_type` varchar(45) NOT NULL,
  `usage_type` varchar(45) NOT NULL,
  `engine_type` varchar(45) DEFAULT NULL,
  `seat_capacity` varchar(45) DEFAULT NULL,
  `fuel_tank_size` varchar(45) DEFAULT NULL,
  `length` varchar(45) NOT NULL,
  `width` varchar(45) NOT NULL,
  `number_of_engines` varchar(45) DEFAULT NULL,
  `emergency_exits` varchar(45) DEFAULT NULL,
  `cargo_compartment_size` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`plane_type`),
  UNIQUE KEY `plane_type_UNIQUE` (`plane_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plane_types`
--

LOCK TABLES `plane_types` WRITE;
/*!40000 ALTER TABLE `plane_types` DISABLE KEYS */;
INSERT INTO `plane_types` VALUES ('Airbus A320','passenger','turbo','120','20','12','6','2','6','80'),('Airbus A321','passenger','turbo','145','23','14','6','2','8','100'),('Boeing 737','passenger','turbo','102','18','11','5','2','4','65'),('Boeing 767','passenger','turbo','200','35','20','7','2','8','145'),('IL-76','cargo','turbo','6','40','23','8','4','1','1300'),('Tu-144','passenger','turbo','87','20','14','7','3','4','55');
/*!40000 ALTER TABLE `plane_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `planes`
--

DROP TABLE IF EXISTS `planes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `planes` (
  `plane_id` int NOT NULL AUTO_INCREMENT,
  `plane_type` varchar(45) NOT NULL,
  `color` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `production_year` date NOT NULL,
  `status` varchar(45) NOT NULL,
  PRIMARY KEY (`plane_id`),
  UNIQUE KEY `plane_id_UNIQUE` (`plane_id`),
  KEY `plane_type_idx` (`plane_type`),
  CONSTRAINT `plane_type` FOREIGN KEY (`plane_type`) REFERENCES `plane_types` (`plane_type`)
) ENGINE=InnoDB AUTO_INCREMENT=9973 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `planes`
--

LOCK TABLES `planes` WRITE;
/*!40000 ALTER TABLE `planes` DISABLE KEYS */;
INSERT INTO `planes` VALUES (7,'Tu-144','White','Joesph Stalin','1974-01-01','inactive'),(12,'Boeing 767','Blue','Admiral Isakov','2019-01-01','active'),(54,'Airbus A320','White','Saro Deravanesian','2008-01-01','active'),(106,'Airbus A321','White','Hovhannes Tumanyan','2017-01-01','active'),(163,'Boeing 737','Black','Mesrop Mashtots','2012-01-01','active'),(213,'Airbus A320','White','Tigran Mets','2014-01-01','active');
/*!40000 ALTER TABLE `planes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `role_id` int NOT NULL AUTO_INCREMENT,
  `role_name` varchar(45) NOT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `role_name_UNIQUE` (`role_name`),
  UNIQUE KEY `role_id_UNIQUE` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (4,'chief'),(2,'co-pilot'),(5,'flight attendant'),(3,'flight engineer'),(1,'pilot');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tickets` (
  `ticket_id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `passenger_id` int NOT NULL,
  `flight_id` int NOT NULL,
  `expiration_date` datetime NOT NULL,
  `class` varchar(45) NOT NULL,
  `ticket_status` varchar(45) NOT NULL,
  PRIMARY KEY (`ticket_id`),
  UNIQUE KEY `ticket_id_UNIQUE` (`ticket_id`),
  KEY `passenger_id_idx` (`passenger_id`),
  KEY `order_id_idx` (`order_id`),
  KEY `flight_id_idx` (`flight_id`),
  CONSTRAINT `flight_id` FOREIGN KEY (`flight_id`) REFERENCES `flights` (`flight_id`),
  CONSTRAINT `order_id` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  CONSTRAINT `passenger_id` FOREIGN KEY (`passenger_id`) REFERENCES `passengers` (`passenger_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7654 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
INSERT INTO `tickets` VALUES (2643,43543,192,5646,'2023-01-14 06:44:17','economy','used'),(3244,37822,566,5432,'2023-02-05 06:44:17','economy','used'),(3323,32434,324,1240,'2023-02-04 06:44:17','economy','active'),(6548,89877,231,8243,'2023-05-01 06:44:17','business','active'),(7653,37822,984,5432,'2023-03-04 06:44:17','economy','used');
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-14 19:43:04
